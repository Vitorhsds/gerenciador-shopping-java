import java.util.Scanner;

public class Main {

    static String[] lojas = new String[20];
    static String[] segmentos = new String[20];

    public static void mostrarMapa() {

        System.out.println("\n=========== MAPA DO SHOPPING ===========\n");

        System.out.printf("[%s] [%s] [%s] [%s] [%s] [%s] [%s]\n",
                nome(0), nome(1), nome(2), nome(3), nome(4), nome(5), nome(6));

        System.out.printf("[%s]                               [%s]\n",
                nome(19), nome(7));

        System.out.printf("[%s]         SHOPPING CENTER        [%s]\n",
                nome(18), nome(8));

        System.out.printf("[%s]                               [%s]\n",
                nome(17), nome(9));

        System.out.printf("[%s] [%s] [%s] [%s] [%s] [%s] [%s]\n",
                nome(16), nome(15), nome(14), nome(13), nome(12), nome(11), nome(10));

        System.out.println();
    }

    public static String nome(int posicao) {

        if (lojas[posicao] == null) {
            return "E" + posicao;
        }

        return lojas[posicao];
    }

    public static void listarLojas() {

        System.out.println("\n===== LOJAS CADASTRADAS =====");

        boolean encontrou = false;

        for (int i = 0; i < 20; i++) {

            if (lojas[i] != null) {

                System.out.println(
                        "E" + i +
                        " - " +
                        lojas[i] +
                        " (" +
                        segmentos[i] +
                        ")");

                encontrou = true;
            }
        }

        if (!encontrou) {
            System.out.println("Nenhuma loja cadastrada.");
        }
    }

    public static void main(String[] args) {

        Scanner teclado = new Scanner(System.in);

        int opcao;

        do {

            System.out.println("\n===== SHOPPING CENTER =====");
            System.out.println("1 - Cadastrar Loja");
            System.out.println("2 - Buscar Loja");
            System.out.println("3 - Alterar Loja");
            System.out.println("4 - Excluir Loja");
            System.out.println("5 - Listar Lojas");
            System.out.println("6 - Mostrar Mapa");
            System.out.println("0 - Sair");

            System.out.print("Opção: ");
            opcao = teclado.nextInt();
            teclado.nextLine();

            switch (opcao) {

                case 1:

                    System.out.print("Espaço (0 a 19): ");
                    int espaco = teclado.nextInt();
                    teclado.nextLine();

                    if (espaco < 0 || espaco > 19) {

                        System.out.println("Espaço inválido.");
                        break;
                    }

                    if (lojas[espaco] != null) {

                        System.out.println("Espaço já ocupado.");
                        break;
                    }

                    System.out.print("Nome da loja: ");
                    lojas[espaco] = teclado.nextLine();

                    System.out.print("Segmento: ");
                    segmentos[espaco] = teclado.nextLine();

                    System.out.println("Loja cadastrada com sucesso.");

                    break;

                case 2:

                    System.out.print("Digite o espaço: ");
                    espaco = teclado.nextInt();
                    teclado.nextLine();

                    if (espaco >= 0 && espaco < 20 && lojas[espaco] != null) {

                        System.out.println("Loja: " + lojas[espaco]);
                        System.out.println("Segmento: " + segmentos[espaco]);

                    } else {

                        System.out.println("Espaço vazio.");
                    }

                    break;

                case 3:

                    System.out.print("Digite o espaço: ");
                    espaco = teclado.nextInt();
                    teclado.nextLine();

                    if (espaco >= 0 && espaco < 20 && lojas[espaco] != null) {

                        System.out.print("Novo nome: ");
                        lojas[espaco] = teclado.nextLine();

                        System.out.print("Novo segmento: ");
                        segmentos[espaco] = teclado.nextLine();

                        System.out.println("Loja alterada.");

                    } else {

                        System.out.println("Espaço vazio.");
                    }

                    break;

                case 4:

                    System.out.print("Digite o espaço: ");
                    espaco = teclado.nextInt();
                    teclado.nextLine();

                    if (espaco >= 0 && espaco < 20 && lojas[espaco] != null) {

                        lojas[espaco] = null;
                        segmentos[espaco] = null;

                        System.out.println("Loja removida.");

                    } else {

                        System.out.println("Espaço vazio.");
                    }

                    break;

                case 5:

                    listarLojas();
                    break;

                case 6:

                    mostrarMapa();
                    break;

                case 0:

                    System.out.println("Sistema encerrado.");
                    break;

                default:

                    System.out.println("Opção inválida.");
            }

        } while (opcao != 0);

        teclado.close();
    }
}